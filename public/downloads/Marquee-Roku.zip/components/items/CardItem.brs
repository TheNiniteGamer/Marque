sub init()
    m.bg = m.top.findNode("bg")
    m.art = m.top.findNode("art")
    m.scrim = m.top.findNode("scrim")
    m.title = m.top.findNode("title")
    m.track = m.top.findNode("track")
    m.bar = m.top.findNode("bar")
    m.badgeBg = m.top.findNode("badgeBg")
    m.badge = m.top.findNode("badge")
    m.initial = m.top.findNode("initial")
end sub

sub onSize()
    w = m.top.width
    h = m.top.height
    if w <= 0 or h <= 0 then return
    m.bg.width = w
    m.bg.height = h
    m.art.width = w
    m.art.height = h
    m.initial.width = w
    m.initial.height = h * 0.8
    ' Crop to fill the card (Roku only keeps the picture's shape when the load size is set).
    m.art.loadWidth = w
    m.art.loadHeight = h
    m.top.clippingRect = [0, 0, w, h]
    m.scrim.width = w
    m.scrim.height = h * 0.65
    m.scrim.translation = [0, h * 0.35]
    m.title.width = w - 32
    m.title.height = h - 24
    m.title.translation = [16, 0]
    m.track.width = w
    m.track.translation = [0, h - 6]
    m.bar.translation = [0, h - 6]
    m.badgeBg.translation = [w - 52, 12]
    m.badge.translation = [w - 52, 12]
    onContent()
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.art.uri = c.HDPosterUrl
    m.title.text = c.title
    ' Someone in the cast without a photo: their initial on their colour.
    noPhoto = c.kind = "person" and c.HDPosterUrl = ""
    m.initial.visible = noPhoto
    if noPhoto then
        m.initial.text = c.initial
        m.bg.color = c.tint
    else
        m.bg.color = "0x242424FF"
    end if
    p = 0.0
    if c.progress <> invalid then p = c.progress
    m.track.visible = p > 0
    m.bar.visible = p > 0
    if m.top.width > 0 then m.bar.width = m.top.width * p
    hasBadge = c.badge <> invalid and c.badge <> ""
    m.badgeBg.visible = hasBadge
    m.badge.visible = hasBadge
    if hasBadge then
        m.badge.text = c.badge
        ' Wider for "#10" (Top 10) than for an unwatched count.
        bw = 40
        if Len(c.badge) > 2 then bw = 60
        m.badgeBg.width = bw
        m.badge.width = bw
        if m.top.width > 0 then
            m.badgeBg.translation = [m.top.width - bw - 12, 12]
            m.badge.translation = [m.top.width - bw - 12, 12]
        end if
    end if
end sub
