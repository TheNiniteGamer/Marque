' Helpers shared by the screens: settings saved on the Roku, server addresses, and turning the
' server's titles into content nodes for rows and grids.

function mqRead(key as String) as String
    sec = CreateObject("roRegistrySection", "marquee")
    if sec.Exists(key) then return sec.Read(key)
    return ""
end function

sub mqWrite(key as String, value as String)
    sec = CreateObject("roRegistrySection", "marquee")
    sec.Write(key, value)
    sec.Flush()
end sub

sub mqDelete(key as String)
    sec = CreateObject("roRegistrySection", "marquee")
    sec.Delete(key)
    sec.Flush()
end sub

function mqIsTrue(v as Dynamic) as Boolean
    if v = invalid then return false
    t = type(v)
    if t = "roBoolean" or t = "Boolean" then return v
    return false
end function

function mqStr(v as Dynamic) as String
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInt" or t = "Integer" or t = "roFloat" or t = "Float" or t = "Double" or t = "roDouble" or t = "LongInteger" then return v.ToStr()
    return ""
end function

function mqNum(v as Dynamic) as Float
    if v = invalid then return 0
    t = type(v)
    if t = "roInt" or t = "Integer" or t = "roFloat" or t = "Float" or t = "Double" or t = "roDouble" or t = "LongInteger" then return v
    return 0
end function

' A playback file or picture on the server. The address carries the media key, which opens only
' pictures and videos (so the sign-in itself never ends up in an address); until the key has
' arrived, the sign-in is used as before.
function mqMediaUrl(path as String) as String
    sep = "?"
    if Instr(1, path, "?") > 0 then sep = "&"
    key = m.global.mediaKey
    if key = invalid or key = "" then key = m.global.token
    return m.global.server + path + sep + "at=" + key
end function

' kind: "backdrop", "poster" or "thumb".
function mqArt(kind as String, item as Object) as String
    v = mqStr(item.artV)
    return mqMediaUrl("/api/art/" + kind + "/" + item.id + "?v=" + v)
end function

' For a search term in an address (UTF-8, percent-encoded).
function mqEscape(s as String) as String
    out = ""
    bytes = CreateObject("roByteArray")
    bytes.FromAsciiString(s)
    for each b in bytes
        if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b = 45 or b = 46 or b = 95 or b = 126 then
            out = out + Chr(b)
        else
            h = UCase(StrI(b, 16))
            if Len(h) = 1 then h = "0" + h
            out = out + "%" + h
        end if
    end for
    return out
end function

function mqDuration(sec as Dynamic) as String
    s = mqNum(sec)
    if s <= 0 then return ""
    mins = Int(s / 60 + 0.5)
    if mins < 1 then return "1 min"
    if mins < 60 then return mins.ToStr() + " min"
    h = Int(mins / 60)
    r = mins - h * 60
    if r = 0 then return h.ToStr() + " hr"
    return h.ToStr() + " hr " + r.ToStr() + " min"
end function

function mqEpLabel(item as Object) as String
    if item.season = invalid and item.episode = invalid then return ""
    out = ""
    if item.season <> invalid then out = "S" + mqStr(item.season)
    if item.episode <> invalid then
        if out <> "" then out = out + ":"
        out = out + "E" + mqStr(item.episode)
    end if
    return out
end function

function mqTimeLeft(item as Object) as String
    p = item.progress
    if p = invalid or type(p) <> "roAssociativeArray" then return ""
    if mqIsTrue(p.watched) or mqNum(p.position) <= 0 or mqNum(item.duration) <= 0 then return ""
    left = mqNum(item.duration) - mqNum(p.position)
    if left < 60 then left = 60
    return mqDuration(left) + " left"
end function

' Card content for rows and grids: the title on the artwork, progress, unwatched count.
function mqCard(item as Object) as Object
    c = CreateObject("roSGNode", "ContentNode")
    kind = mqStr(item.type)
    title = mqStr(item.title)
    art = "backdrop"
    sub_ = ""
    if kind = "episode" then
        title = mqStr(item.showTitle)
        art = "thumb"
        sub_ = mqEpLabel(item) + " · " + mqStr(item.title)
    else if kind = "show" then
        sub_ = mqStr(item.seasonCount) + " seasons"
    else
        sub_ = mqStr(item.year)
    end if
    progress = 0.0
    p = item.progress
    if p <> invalid and type(p) = "roAssociativeArray" and not mqIsTrue(p.watched) and mqNum(item.duration) > 0 then
        progress = mqNum(p.position) / mqNum(item.duration)
    end if
    badge = ""
    if kind = "show" and mqNum(item.unwatchedCount) > 0 and mqNum(item.unwatchedCount) < mqNum(item.episodeCount) then badge = mqStr(item.unwatchedCount)
    ' Top 10 in your house: the rank.
    if item.rank <> invalid then badge = "#" + mqStr(item.rank)
    c.addFields({ kind: kind, progress: progress, badge: badge, sub: sub_, data: item })
    c.id = item.id
    c.title = title
    c.HDPosterUrl = mqArt(art, item)
    return c
end function

' "Coming soon" (a show's next episode, or a film on its way): its artwork and when.
function mqUpcomingCard(item as Object) as Object
    c = CreateObject("roSGNode", "ContentNode")
    sub_ = mqStr(item.release)
    if item.kind = "episode" then
        sub_ = "S" + mqStr(item.season) + ":E" + mqStr(item.episode)
        if item.episodeTitle <> invalid then sub_ = sub_ + " · " + mqStr(item.episodeTitle)
    end if
    c.addFields({ kind: "upcoming", progress: 0.0, badge: mqSoonDate(mqStr(item.airDate)), sub: sub_, data: item })
    c.id = item.id
    c.title = mqStr(item.title)
    if item.kind = "episode" then
        c.HDPosterUrl = mqArt("backdrop", { id: item.showId, artV: item.artV })
    else if item.image <> invalid then
        c.HDPosterUrl = mqStr(item.image)
    end if
    return c
end function

' "Today", "Tomorrow", "Fri", or "24 Oct" for an ISO date.
function mqSoonDate(iso as String) as String
    when = CreateObject("roDateTime")
    when.FromISO8601String(Left(iso, 10) + " 12:00:00")
    today = CreateObject("roDateTime")
    today.ToLocalTime()
    today.FromISO8601String(Left(today.ToISOString(), 10) + " 12:00:00")
    days = Int((when.AsSeconds() - today.AsSeconds()) / 86400)
    if days <= 0 then return "Today"
    if days = 1 then return "Tomorrow"
    if days < 7 then return Left(when.GetWeekday(), 3)
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return when.GetDayOfMonth().ToStr() + " " + months[when.GetMonth() - 1]
end function

' Starts a request to the server; `callback` (a function name in the caller) gets the response
' { status, data, error, tag } as the event's data.
function mqApi(path as String, callback as String, method = "GET" as String, body = invalid as Dynamic, tag = "" as String) as Object
    t = CreateObject("roSGNode", "ApiTask")
    t.request = { path: path, method: method, body: body, tag: tag }
    t.observeField("response", callback)
    t.control = "RUN"
    if m.tasks = invalid then m.tasks = []
    ' Keep a reference until it's done; drop finished ones.
    keep = [t]
    for each old in m.tasks
        if old.state <> "done" and old.state <> "stop" then keep.Push(old)
    end for
    m.tasks = keep
    return t
end function

' 0:42 / 12:05 / 1:02:33
function mqClock(sec as Dynamic) as String
    s = Int(mqNum(sec))
    if s < 0 then s = 0
    h = Int(s / 3600)
    mi = Int((s - h * 3600) / 60)
    se = s - h * 3600 - mi * 60
    ss = se.ToStr()
    if se < 10 then ss = "0" + ss
    if h > 0 then
        ms = mi.ToStr()
        if mi < 10 then ms = "0" + ms
        return h.ToStr() + ":" + ms + ":" + ss
    end if
    return mi.ToStr() + ":" + ss
end function

' What choosing something in the top bar (TopBar) opens. fromHome: the bar is on Home; elsewhere a
' library replaces the page you're on, and Home goes back to it.
function mqTopBarNav(c as Object, fromHome as Boolean) as Object
    if c.key = "home" then return { back: true }
    if c.key = "search" then return { screen: "SearchScreen" }
    if c.key = "profiles" then return { screen: "ProfilesScreen", params: {} }
    params = { title: "My List", path: "/api/watchlist", current: "list" }
    if c.key = "lib" then params = { title: mqStr(c.title), path: "/api/libraries/" + mqStr(c.id) + "/items", current: "lib:" + mqStr(c.id) }
    return { screen: "GridScreen", params: params, replace: not fromHome }
end function

' A steady colour per person, the same as on the web.
function mqAvatarColor(name as String) as String
    colors = ["0x2F6FB3FF", "0xB3402FFF", "0x7A4FB3FF", "0x2F8A5CFF", "0xB3862FFF", "0x2F9BB3FF", "0xB32F7AFF", "0x5C6B2FFF"]
    n& = 7
    for i = 1 to Len(name)
        n& = (n& * 31 + Asc(Mid(name, i, 1))) mod 4294967296&
    end for
    return colors[n& mod colors.Count()]
end function
